package com.cookandroid.practice1;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends AppCompatActivity {

    String databaseName;
    String tableName;
    TextView status;
    boolean databaseCreated = false;
    boolean tableCreated = false;

    SQLiteDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText databaseNameInput = (EditText) findViewByld(R.id.databaseNameInput);
        final EditText tableNameInput = (EditText) findViewByld(R.id.tableNameInput);

        Button createDatabaseBtn = (Button) findViewByld(R.id.createDatabaseBtn);
        createDatabaseBtn.setOnClickListener(new View.OnClickListener()){
            public void onClick(View v) {
                databaseName = databaseNameInput.getText().toString();
                createDataBase(databaseName);
            }
        });
        Button createTableBtn = (Button) findViewByld(R.id.createTableBtn);
        createTableBtn.setOnClickListener(new view.OnClickListener()) {
            public void onClick(View v) {
                tableName = tableNameInput.getText().toString();
                createTable(tablename);
                int count = insertRecord(tableName);
                printIn(count + "records inserted.")
            }
        });
        status = (TextView) findViewByld(R.id.status);

        private int insertRecordParam(String name) {
        printIn("inserting records using parameters.");

        int count = 1;
        ContentValues recordValues = new ContentValues();

        recordValues.put("name", "Rice");
        recordValues.put("age", 43);
        recordValues.put("Pill", "부루펜");
        int rowPosition = (int) db.insert(name, null, recordValues);

        return count;
    }
    private int updatingRecordParam(String name) {
        printIn("updating records using parameters");

        ContentValues recordValues = new ContentValues();
        recordValues.put("age", 43);
        String[] whereArgs = {"Rice"};

        int rowAffected = db.updating(name,
                recordValues,
                "name = ?",
                whereArgs);

        return rowAffected;
    }
}
    private void createDatabase(String name) {
        printIn("creating database [" + name + "],");

        try {
            db = openOrCreateDatabase(
                    name,
                    Activity.MODE_PRIVATE,
                    null);
            databaseCreated = true;
            printIn("database is created.");
        } catch(Exception ex) {
            ex.printStackTrace();
            printIn("database is not created.");

        }
    }

    private void createTable(String name) {
        printIn("creating table [" + name + "].");

        db.execSQL("create table if not exists " + name + "("
        + " _id integer PRIMARY KEY autoincrement, "
        + " name text, "
        + " age integer, "
        + "pill text);" );
        tableCreated = true;
    }
    private int insertRecord(String name) {
        printIn("inserting records into table " + name + ".");

        int count = 3;
        db.execSQL( "insert into " + name + "(name, age, pill) values ('Rudd', 20, '부루펜');" );
        db.execSQL( "insert into " + name + "(name, age, pill) values ('suru', 35, '뮤코라제');" );
        db.execSQL( "insert into " + name + "(name, age, pill) values ('esther', 26, '시메티딘');" );

        return count;
    }

    private int deleteRecordParam(String name) {
        printIn("deleting records using parameters.");

        String[] whereArgs = {"Rice"};

        int rowAffected = db.delete(name,
                "name = ?",
                whereArgs);
        return rowAffected;
    }

    private void printIn(String msg) {
        Log.d("SampleDatabase", msg);
        status.append("\n" + msg);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
