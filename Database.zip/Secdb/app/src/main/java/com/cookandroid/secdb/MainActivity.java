package com.cookandroid.secdb;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends Activity {

    private Button btnCreateDatabase;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCreateDatabase = (Button) findViewByld(R.id.btnCreateDatabase);
        btnCreateDatabase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView tvDBName = new TextView(MainActivity.this);
                tvDBName.setHint("DB명을 입력하세요");

                //Dialog로database의 이름을 입력 받음
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog .setTitle("Database 이름 입력")
                        .setMessage("Database 이름 입력")
                        .setView(tvDBName)
                        .setPositiveButton("생성", new DialogInteface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if ( etDBName.getText().toString().length() > 0 ) {
                                    dbHelper = new DBHelper(MainActivity.this ,
                                            etDBName.getText().toString(),
                                            null,
                                            1);
                                    dbHelper.testDB();
                                }


                            }
                        })
                        .setNeutralButton("취소", new DialogInterfac.OnClickListener() {
                            @Override
                            piblic void onClick(DialogInterface dialog, int which) {

                            }
                        }).create().show();
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
