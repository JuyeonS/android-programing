package com.example.newdatabase;

import android.content.Context;

import android.content.Intent;

import android.database.Cursor;

import android.database.sqlite.SQLiteDatabase;

import android.database.sqlite.SQLiteOpenHelper;

import android.os.Bundle;

import android.support.v7.app.ActionBarActivity;

import android.view.Menu;

import android.view.MenuItem;

import android.view.View;

import android.widget.EditText;

import android.widget.RadioButton;

import android.widget.RadioGroup;

import android.widget.TextView;

import android.widget.Toast;

public class MainActivity extends ActionBarActivity {
    EditText editName, editAge, editNum, editMajor;
    TextView textView;
    String databaseName;
    SQLiteDatabase database;
    String tableName;
    String Name;
    String Age;
    String Num;
    String Major;
    String Gender;
    EditText editText;
    EditText editText2;
    String Text;
    String Text2;
    CustomerDatabaseHelper databaseHelper;
    String Cname;
    String Cmajor;
    // String resultText;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = (EditText)findViewById(R.id.editText);
        editText2 = (EditText)findViewById(R.id.editText2);
        editName = (EditText)findViewById(R.id.editName);
        editAge = (EditText)findViewById(R.id.editAge);
        editNum = (EditText)findViewById(R.id.editNum);
        editMajor = (EditText)findViewById(R.id.editMajor);
        textView = (TextView)findViewById(R.id.textView);
        databaseName = "member";
        try{
            if(database==null){
                //database = openOrCreateDatabase(databaseName, Context.MODE_PRIVATE,null);
                databaseHelper = new CustomerDatabaseHelper(getApplicationContext(),databaseName,null,1);
                database = databaseHelper.getWritableDatabase();
                Toast.makeText(this,"DB :"+databaseName+"생성",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        tableName = "JOIN";
        try{
            //   tableName = "join";
            if (database != null) {
                database.execSQL("CREATE TABLE if not exists " + "PORODUCT" + "(" +
                        "_id integer PRIMARY KEY autoincrement," +
                        "name text," +
                        "age integer," +
                        "num integer," +
                        "major text" +
                        ")");
                Toast.makeText(this,"table :" + "PORODUCT" + "생성",Toast.LENGTH_SHORT).show();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void Button1OnClicked(View v){
        try {
            if(tableName==null){
                //       tableName = "join";
            }
            if(database!=null){
                Name = editName.getText().toString();
                Age = editAge.getText().toString();
                Num = editNum.getText().toString();
                Major= editMajor.getText().toString();
                database.execSQL("INSERT INTO " + "PORODUCT" + "(name, age, num, major) VALUES" +
                        "("+"'"+Name+"'"+","+Age+","+Num+","+"'"+Major+"'"+");");
                println("데이터를 추가했습니다.");
            }
            else {
                println("데이터베이스를 먼저 열어야합니다.");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void Button2OnClicked(View v){
        try {
            if(tableName==null){
                //     tableName = "join";
            }
            if(database!=null){
                Cursor cursor =database.rawQuery("SELECT name, age, Num, major FROM " + "PORODUCT", null);
                int count = cursor.getCount();
                println("결과 레코드 갯수 :"+count);
                for(int i=0;i<count;i++){
                    cursor.moveToNext();
                    String name = cursor.getString(0);
                    int age = cursor.getInt(1);
                    int num = cursor.getInt(2);
                    String major = cursor.getString(3);
                    //String gender = cursor.getString(4);
                    println("레코드 # "+i+": "+name+","+age+","+num+","+major);
                }
                cursor.close();
                println("데이터를 조회했습니다.");
            }
            else {
                println("데이터베이스를 먼저 열어야합니다.");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void println(String data){
        textView.append(data+"\n");
    }
    class CustomerDatabaseHelper extends SQLiteOpenHelper {
        CustomerDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override

        public void onOpen(SQLiteDatabase database) {
            super.onOpen(database);

            Toast.makeText(getApplicationContext(),"Helper의 onOpen()호출됨",Toast.LENGTH_LONG).show();
        }

        @Override

        public void onCreate(SQLiteDatabase database) {
            Toast.makeText(getApplicationContext(),"Helper의 onCreate()호출됨",Toast.LENGTH_LONG).show();
            //createTable(database);
        }

        @Override

        public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
            Toast.makeText(getApplicationContext(),"Helper의 onUpgrade()호출됨 :"+oldVersion+" => "+newVersion,Toast.LENGTH_LONG).show();
            //    changeTable(database);
        }
    }

    public void login(View v) {
        if (database != null) {
            Cursor cursor = database.rawQuery("SELECT name, major FROM " + "PORODUCT", null);
            int count = cursor.getCount(); // 이 코드가 있어야 등록된 정보들을 전부 불러올 수
            for(int i=0;i<count;i++) {       // 있습니다. 이 코드만 추가해주시면 가입한 모든 아이디
            cursor.moveToNext();
            Cname = cursor.getString(0);
            Cmajor = cursor.getString(1);
            Text = editText.getText().toString();
            Text2 = editText2.getText().toString();
            if (Text.equals(Cname) && Text2.equals(Cmajor)) {//내장디비인 SQLite에서 가져온 이름, 전공과 입력한 이름, 전공을 비교하여 같으면 로그인이 되게한다.
                Intent intent = new Intent(getApplication(), NewPage.class);
                startActivity(intent);
                Toast.makeText(getApplication(),Text+"님 환영합니다.",Toast.LENGTH_SHORT).show();
                finish();
            }
            cursor.close();
        }
    }

    @Override

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}